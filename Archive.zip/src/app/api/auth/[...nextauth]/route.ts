import NextAuth from "next-auth/next";
import { AuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import userLogin from "@/libs/userLogin";

export const authOptions: AuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email", placeholder: "Email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials, req) {
        if (!credentials) return null;
        const user = await userLogin(credentials.email, credentials.password);
        console.log(user); // Ensure `user.role` exists in the logged data

        if (user) {
          // Return the user object, including the role
          return {
            id: user._id,
            name: user.name,
            email: user.email,
            role: user.role, // Ensure role is included here
          };
        } else {
          return null; // Invalid credentials
        }
      },
    }),
  ],
  session: { strategy: "jwt" },
  callbacks: {
    // Add role to the JWT
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role; // Add role to token
      }
      return token;
    },
    // Add role to the session
    async session({ session, token }) {
      session.user = {
        ...session.user,
        role: token.role, // Include role in session
      };
      return session;
    },
    async redirect({ url, baseUrl }) {
      return baseUrl; // Always redirect to the home page
    },
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };