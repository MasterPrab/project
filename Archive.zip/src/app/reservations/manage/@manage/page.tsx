export default function ManagePage () {
    return (
        <main>
            <div>Your Reservation</div>
        </main>
    )

}