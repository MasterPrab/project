export default function ManageReservations(){
    return(
        <main className="text-center text-lg">
            <div>Your Reservationnnn</div>
        </main>
    )
}