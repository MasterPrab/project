export default function About() {
    return(
        <main>
            <div>About us</div>
            
        </main>
    );
}