
import styles from './about.module.css';

export default function About() {
    return (
        <>
            
            <main className={styles.aboutContainer}>
                <div>About us</div>
            </main>
        </>
    );
}