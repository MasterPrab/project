"use client";
import ReservationCart from "@/components/ReservationCard";

export default function CartPage() {
  return (
    <main>
      <ReservationCart>
        
      </ReservationCart>
    </main>
  );
}