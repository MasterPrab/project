import styles from './reservationmenu.module.css'

export default function ReservationMenu() {
    return (
        <div>
            
        </div>
    );
}